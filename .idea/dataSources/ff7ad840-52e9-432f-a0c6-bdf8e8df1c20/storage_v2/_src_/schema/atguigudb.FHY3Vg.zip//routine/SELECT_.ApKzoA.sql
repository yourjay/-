create
    definer = root@localhost procedure SELECT_()
BEGIN
			SELECT *
			FROM course;
END;

