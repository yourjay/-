create
    definer = root@localhost procedure youbiao(OUT count int)
BEGIN
			DECLARE cnt INT DEFAULT 0;
			
      DECLARE SOR CURSOR FOR SELECT * FROM COURSE WHERE credit>2;
			
			OPEN SOR;
			
			REPEAT
						SET cnt=cnt+1;
 UNTIL cnt>=3
END REPEAT;

CLOSE SOR;

END;

