create
    definer = root@localhost procedure youbiao3(OUT count int, IN num int)
BEGIN
			DECLARE cnt INT DEFAULT 0;
			DECLARE NNAME VARCHAR(20);
			DECLARE IID INT;
			DECLARE CCREDIT INT;
      DECLARE SOR CURSOR FOR SELECT * FROM COURSE ;
			
			OPEN SOR;
			
			WHILE num IS NOT NULL DO
			FETCH SOR INTO IID,NNAME,CCREDIT;
			IF (CCREDIT>3)
          THEN SET cnt=cnt+1,num=num-1;
			ELSE SET num=num-1;
			END IF;	
END WHILE;

			
CLOSE SOR;

END;

