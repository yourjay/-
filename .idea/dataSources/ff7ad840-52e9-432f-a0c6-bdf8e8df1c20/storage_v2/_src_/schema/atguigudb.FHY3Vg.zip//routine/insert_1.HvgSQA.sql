create
    definer = root@localhost procedure insert_1(IN id int, IN name varchar(20), IN redit decimal(10, 2))
BEGIN
			INSERT INTO course(id,name,credit)
			VALUES(id,name,redit);
END;

