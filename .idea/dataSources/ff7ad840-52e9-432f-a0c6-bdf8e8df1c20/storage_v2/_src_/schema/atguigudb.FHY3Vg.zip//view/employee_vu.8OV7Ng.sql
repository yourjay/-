create definer = root@localhost view employee_vu as
select `atguigudb`.`employees`.`last_name`     AS `LAST_NAME`,
       `atguigudb`.`employees`.`employee_id`   AS `EMPLOYEE_ID`,
       `atguigudb`.`employees`.`department_id` AS `DEPARTMENT_ID`
from `atguigudb`.`employees`
where (`atguigudb`.`employees`.`department_id` = 80);

