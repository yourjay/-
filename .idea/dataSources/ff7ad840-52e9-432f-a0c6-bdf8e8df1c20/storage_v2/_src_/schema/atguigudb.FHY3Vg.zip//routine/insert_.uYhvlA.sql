create
    definer = root@localhost procedure insert_(IN id int, IN name varchar(20), IN redit decimal(10, 2))
BEGIN
			INSERT INTO course(id,name,redit)
			VALUES(id,name,redit);
END;

