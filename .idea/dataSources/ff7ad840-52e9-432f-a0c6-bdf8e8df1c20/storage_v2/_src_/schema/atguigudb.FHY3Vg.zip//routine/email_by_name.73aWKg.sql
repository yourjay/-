create
    definer = root@localhost function email_by_name() returns varchar(25) deterministic reads sql data
BEGIN
			RETURN (SELECT email
			FROM employees
			WHERE last_name='Abel');

END;

