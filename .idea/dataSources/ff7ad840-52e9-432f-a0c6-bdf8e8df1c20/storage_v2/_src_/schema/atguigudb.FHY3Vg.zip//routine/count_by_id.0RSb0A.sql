create
    definer = root@localhost function count_by_id(dept_id int) returns int deterministic reads sql data
BEGIN
RETURN(SELECT COUNT(1)
FROM employees
WHERE department_id=dept_id);
END;

