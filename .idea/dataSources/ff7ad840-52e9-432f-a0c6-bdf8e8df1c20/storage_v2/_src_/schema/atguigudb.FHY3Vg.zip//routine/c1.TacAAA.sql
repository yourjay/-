create
    definer = root@localhost procedure c1()
BEGIN
   SELECT NAME
	FROM course
	WHERE credit>3;
END;

