create
    definer = root@localhost procedure c()
BEGIN
   SELECT NAME
	FROM course
	WHERE creadit>3;
END;

