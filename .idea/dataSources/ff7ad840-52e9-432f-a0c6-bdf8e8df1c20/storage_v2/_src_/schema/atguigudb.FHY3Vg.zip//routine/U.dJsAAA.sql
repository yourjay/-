create
    definer = root@localhost procedure U()
BEGIN
DECLARE CONTINUE HANDLER FOR 1048 SET @PRC_BALUE=-1;

SET @X=1;
UPDATE employees SET email=NULL WHERE last_name='Abel';
SET @x=2;
UPDATE employees SET email='aabbel'WHERE last_name='Abel';
SET @x=3;
END;

