create
    definer = root@localhost function email_by_id(emp_id int) returns varchar(25) deterministic reads sql data
BEGIN 
RETURN (SELECT email
FROM employees
WHERE employee_id=emp_id
);
END;

