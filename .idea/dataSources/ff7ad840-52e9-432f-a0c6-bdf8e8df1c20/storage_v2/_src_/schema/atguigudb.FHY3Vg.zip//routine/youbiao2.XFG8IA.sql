create
    definer = root@localhost procedure youbiao2(OUT count int, IN num int)
BEGIN
			DECLARE cnt INT DEFAULT 0;
			DECLARE NNAME VARCHAR(20);
			DECLARE IID INT;
			DECLARE CCREDIT INT;
      DECLARE SOR CURSOR FOR SELECT * FROM COURSE ;
			
			OPEN SOR;
			
			WHILE num IS NOT NULL DO
			FETCH SOR INTO IID,NNAME,CCREDIT;
			IF (CCREDIT>3)
          THEN SET cnt=cnt+1,NUM=NUM-1;
			ELSE SET NUM=NUM-1;
			END IF;	
END WHILE;

			
CLOSE SOR;

END;

